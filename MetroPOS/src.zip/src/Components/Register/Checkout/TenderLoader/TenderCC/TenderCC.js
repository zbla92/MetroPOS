import React from 'react';

export default function TenderCC() {
    return(
        <div>TenderCC</div>
    );
}