import React from 'react';

export default function TenderCash() {
    return(
        <div>Cash</div>
    );
}